# Chapter 9 Source Code
This repo contains all the source code related to Chapter 9 of the **Hands-On Deep Learning with Apache Spark** book.  
This is the list of the projects in this repo:  
- *nnevaluation*: a Scala example of NN model performance evaluation with DL4J.    
  
  

