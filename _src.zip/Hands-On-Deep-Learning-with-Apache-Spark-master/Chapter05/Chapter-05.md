# Chapter 5 Source Code
The source code for Chapter 5 of the **Hands-On Deep Learning with Apache Spark** book has been merged with the source code for chapter 8.  

  
  

