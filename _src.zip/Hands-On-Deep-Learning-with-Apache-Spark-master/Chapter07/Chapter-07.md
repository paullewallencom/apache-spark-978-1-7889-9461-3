# Chapter 7 Source Code
This repo contains all the source code related to Chapter 7 of the **Hands-On Deep Learning with Apache Spark** book.  
This is the list of the projects in this repo:  
- *cnntraining*: a Scala example of CNN model training with DL4J on Apache Spark using the [MNIST data set](http://yann.lecun.com/exdb/mnist/).    
  
  

