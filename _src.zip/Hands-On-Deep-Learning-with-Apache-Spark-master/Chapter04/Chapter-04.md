# Chapter 4 Source Code
This repo contains all the source code related to Chapter 4 of the **Hands-On Deep Learning with Apache Spark** book.  
This is the list of the projects in this repo:  
- *sparkstreamingkafka*: a collection of Scala examples about streaming with Spark Streaming, Spark Structured Streaming, [Apache Kafka](https://kafka.apache.org/) and DL4J DataVec.  
  
  
  

